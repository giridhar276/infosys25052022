



import requests
 
url = 'https://crawler-test.com/'
response = requests.get(url)
 
print('URL: ', response.url)
print('Status code: ', response.status_code)
print('HTTP header: ', response.headers)



'''
text, data descriptor    : Content of the response, in unicode.
content, data descriptor : Content of the response, in bytes.
url, attribute           : URL of the request
status_code, attribute   : Status code returned by the server
headers, attribute       : HTTP headers returned by the server
history, attribute       : list of response objects holding the history of request
links, attribute         : Returns the parsed header links of the response, if any.
json, method             : Returns the json-encoded content of a response, if any.
'''