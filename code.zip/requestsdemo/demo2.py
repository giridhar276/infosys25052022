

import requests
 
url = 'https://crawler-test.com/'
payload = {
    'name':'Jean-Christophe',
    'last_name':'Chouinard',
    'website':'https://www.jcchouinard.com/'
    }
 
response = requests.post(url , data = payload)
 
response.json()