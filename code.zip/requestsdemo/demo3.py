

import requests
 
url = 'http://archive.org/wayback/available?url=jcchouinard.com'
response = requests.get(url)
 
print(response.text)   # access response data atributes and descriptors
print(response.json()) # access response methods




#Process the Response

import requests
 
url = 'https://crawler-test.com/'
r = requests.get(url)
 
print(r.status_code)
# 200



#get html page

import requests
 
url = 'https://crawler-test.com/'
r = requests.get(url)
 
print(r.text) # get content as a string
print("---------------")
print(r.content) # get content as byte



#Show HTTP header


import requests
 
url = 'https://crawler-test.com/'
r = requests.get(url)
print(r.headers)


#Show redirections
import requests
 
url = 'https://crawler-test.com/redirects/redirect_chain_allowed'
r = requests.get(url)
 
for redirect in r.history:
    print(redirect.url, redirect.status_code)
print(r.url, r.status_code)



#Parse the HTML with Request and BeautifulSoup


from bs4 import BeautifulSoup
import requests
 
# Make the request
url = 'https://crawler-test.com/'
r = requests.get(url)
print(r.text[:500])


# Parse the HTML
soup = BeautifulSoup(r.text, 'html.parser')
print(soup)










#Getting main SEO tags from a webpage

from bs4 import BeautifulSoup
import requests
 
# Make the request
url = 'https://crawler-test.com/'
r = requests.get(url)
 
# Parse the HTML
soup = BeautifulSoup(r.text, 'html.parser')
 
# Get the HTML tags
title = soup.find('title')
h1 = soup.find('h1')
description = soup.find('meta', attrs={'name':'description'})
meta_robots =  soup.find('meta', attrs={'name':'robots'})
canonical = soup.find('link', {'rel': 'canonical'})
 
# Get the text from the HTML tags
title = title.get_text() if title else ''
h1 = h1.get_text() if h1 else ''
description = description['content'] if description else ''
meta_robots =  meta_robots['content'] if meta_robots else ''
canonical = canonical['href'] if canonical else ''
 
# Print the tags
print('Title: ', title)
print('h1: ', h1)
print('description: ', description)
print('meta_robots: ', meta_robots)
print('canonical: ', canonical)





#Extracting all the links on a page

from bs4 import BeautifulSoup
import requests
from urllib.parse import urljoin
 
url = 'https://crawler-test.com/'
r = requests.get(url)
soup = BeautifulSoup(r.text, 'html.parser')
 
links = []
for link in soup.find_all('a', href=True):
    full_url = urljoin(url, link['href']) # join domain to path
    links.append(full_url)
 
# Show 5 links
links[:5]



#Improve the Request
import requests
 
url = 'bad url'
 
try:
    r = requests.get(url)
except Exception as e:
    print(f'There was an error: {e}')
    
    
    
    
    
#Change User-Agent
import requests 
 
url = 'https://www.reddit.com/r/python/top.json?limit=1&t=day'
 
headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36'
}
 
r = requests.get(url, headers=headers)




#Add Timeout to request


import requests
 
url = 'http://httpbin.org/basic-auth/user/pass'
 
try:
    r = requests.get(url, timeout=0.1)
except Exception as e:
    print(e)
 
r.status_code






#Use Proxies

import requests 
 
url = 'https://crawler-test.com/'
 
proxies = {
    'http': '128.199.237.57:8080'
}
 
r = requests.get(url, proxies=proxies)




#Add Headers to Requests
import requests 
 
url = 'http://httpbin.org/headers'
 
access_token = {
    'Authorization': 'Bearer {access_token}'
    }
 
r = requests.get(url, headers=access_token)
r.json()





'''
Requests Session
The session object is useful when you need to make requests with parameters that persist through all the requests in a single session.''
'''

import requests
 
session = requests.Session()
 
url = 'https://httpbin.org/headers'
 
access_token = {
    'Authorization': 'Bearer {access_token}'
    }
 
session.headers.update(access_token)
 
r1 = session.get(url)
r2 = session.get(url)
 
print('r1: ', r1.json()['headers']['Authorization'])
print('r2: ', r2.json()['headers']['Authorization'])





    

