import time

def another_decorator(fn):
    def wrapper(*args):
        print("well, gonna sleep again")
        fn(*args)
        print("time to wake up!")
    return wrapper


@another_decorator
def another_lazy_function(period, level):
    print("%s..." % ('z'*level))
    time.sleep(period)


# calling another lazy function
another_lazy_function(5, 5)
