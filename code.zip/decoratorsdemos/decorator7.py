

def func_name_printer(func):
    def wrapper(*args):
        print("Function that started running is " + func.__name__)
        func(*args)
    return wrapper

@func_name_printer
def add(*args):
    tot_sum = 0
    for arg in args:
        tot_sum += arg
    print("result = " + str(tot_sum))
    
@func_name_printer
def sub(*args):
    tot_sub = args[0]-args[1]
    print("result = " + str(tot_sub))

@func_name_printer
def mul(*args):
    tot_mul = 1
    for arg in args:
        tot_mul *= arg
    print("result = " + str(tot_mul))   
    
add(1,2)
mul(1,2,3)
sub(400, 150)