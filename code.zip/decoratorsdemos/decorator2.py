import time
def simple_decorator(fn):
    def wrapper():
        # adding behaviour before execution
        print("before execution")
        fn() 
        # adding behaviour after execution
        print("after execution")
    return wrapper


@simple_decorator
def lazy_function():
    print("zz...")
    time.sleep(2)


# Calling the lazy function to see the result
lazy_function()