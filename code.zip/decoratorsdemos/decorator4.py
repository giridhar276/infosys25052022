
import time


def load(level):
    def wrap(fn):
        def wrapper():
            for i in range(level):
                
                print('.')
                time.sleep(0.5)
            fn()
        return wrapper 
    return wrap


@load(5)
def fire():
    print("Bang!")


# let's try to bang!
fire()